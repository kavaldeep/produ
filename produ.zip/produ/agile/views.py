from django.shortcuts import render
from tache_app.models import Tache

# Create your views here.
"""
Grace a cette view on va aller dans la base de donnees recuperer toutes les taches et les afficher
dans la page html

"""

def recup_tache(request):

	return render(request , 'agile/agile.html' , {"listTache":Tache.objects.all()  } )
