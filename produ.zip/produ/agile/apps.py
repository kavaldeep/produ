from django.apps import AppConfig


class AgileConfig(AppConfig):
    name = 'agile'
