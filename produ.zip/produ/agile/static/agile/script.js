console.log("toi je sais pas mais moi mon script il marche ");



