from django.db import models
from django.utils import timezone


class Tache(models.Model):
    """
    Tache Etait ----> Contiendra l etat de la tache : Encours , A faire , FINIT
    Date de Creation ----> La date quand la tache etait mise en ligne
    Contenue ----> Quelles est le contenue les instruction les chose a faire
    TempsAConsacrer ----> Combien de temps on va donner a la tache
    Deadline ----> pour quand est ce que c est a finir
    TempsConsacrer -----------> Le temps qu on a mis deja pour faire le projet
                Temps Restant = TempsAConsacer - TempsConsacrer
    on arrive pas a avoir un string dans django view donc on utlise les int
    PauseOuPlay----------> pause ou play la valeur 0 signfie pause
   TempsTemp-------------> variable pour enregistrer un temps temporaire pour
			   calculer le temps passer a travailer
    TempsClé -----------> contient les clés pour acceder au temps correspandant
			   dans la classe TacheTemps  merci
    """
    PrioriteChoice = [
            (  0   , "non important , non urgent"),
            ( 1 ," important ,  non urgent" ),
            (2,"non important , urgent"),
            ( 3,"import tant , urgent" ),
    ]
    EtatsChoice = [
            ("A faire" , "A faire"),
            ("En Cours" , "En Cours"),
            ("Finis" , "Finis"),
        ]



    Etat = models.CharField(max_length = 100 , choices=EtatsChoice)
    DateDeCreation = models.DateTimeField(null = False , blank = False , auto_now=True)
    Contenue = models.TextField()
    PauseouPlay = models.IntegerField(default = 0)
    TempsAConsacrer = models.FloatField(default = 0.0)
    TempsConsacrer = models.FloatField(default=0.0)
    Deadline = models.DateField(default = timezone.now)
    FinishDate = models.DateField(null = True , blank = True )
    TempsTemp = models.DateTimeField(auto_now=True)
    TempsCle  = models.TextField(default = "")
    Priorite = models.IntegerField( default = 0 , choices = PrioriteChoice)

    def __str__(self):
        return self.Etat




class TacheTemps(models.Model):
	"""Dans cette classe on va enregistrer les temps
           de travail debut et fin pour chaque tache
	  ca va contenir un string qu on pourra retirer apres
	"""
	TempsList = models.CharField(max_length = 100)

	def __str__(self):
		return self.TempsList



class FausseBase(models.Model):
	"""
	Fausse base pour faire des tests et afficher graphique
	"""
	TempsList = models.CharField(max_length = 100)

	def __str__(self):
		return self.TempsList
