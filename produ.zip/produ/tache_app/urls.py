"""Mettre les urls pour la tache app etc etc etc """
from django.urls import path 
from django.conf.urls import url
from . import views

"""
	addToContenue l url avec add to contenue pour recevoir les post ajax
"""
urlpatterns = [
        path('tache_ajouter/' , views.tache_ajouter , name='tache_ajouter' ),
	url(r'^TacheCreate$', views.TacheCreate.as_view(), name='TacheCreate'),		

	url(r'^TacheUpdate/(?P<pk>\d+)$', views.TacheUpdate.as_view(), name='TacheUpdate'),

	url(r'^TacheDelete/(?P<pk>\d+)$', views.TacheDelete.as_view(), name='TacheDelete'),	
	url(r'^ChangeToEnCours$', views.ChangeToEnCours, name='ChangeToEnCours'),
	url(r'^ChangeToAFaire$', views.ChangeToAFaire, name='ChangeToAFaire'),
	url(r'^ChangeToFinis$', views.ChangeToFinis, name='ChangeToFinis'),
	url(r'^addToContenue$', views.addToContenue, name='addToContenue'),
]
