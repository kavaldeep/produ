from django.apps import AppConfig


class TacheAppConfig(AppConfig):
    name = 'tache_app'
